#include <jni.h>
#include <string>
#include <opencv2/opencv.hpp>
#include "include/System.h"
#include "include/Converter.h"
#include "Common.h"
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <mutex>
#include "Osmap.h"

extern "C" {
std::string file_path;

ORB_SLAM2::System *slamSys;
ORB_SLAM2::Osmap *osmap;

float fx,fy,cx,cy;
double timeStamp;
bool slamInited=false;
vector<ORB_SLAM2::MapPoint*> vMPs;
vector<cv::KeyPoint> vKeys;
cv::Mat Tcw;
//std::mutex mMutex;
const int PLANE_DETECTED=233;
const int PLANE_NOT_DETECTED=1234;

const bool DRAW_STATUS= false;

cv::Mat pSrc;
double mModelview_matrix[16];
double translation[3];
double quaternion[4];
bool flag = false;
struct Color32
{
    uchar red;
    uchar green;
    uchar blue;
    uchar alpha;
};

bool init_slam(const unsigned char* str, int length){
    string path_name(reinterpret_cast<const char*>(str), length);
    file_path = path_name;
    //    string ORBVOC = "/storage/emulated/0/Android/data/com.DefaultCompany.AvatarSLAM_plugins/files/SLAM/ORBvoc.txt";
//    string setting = "/storage/emulated/0/Android/data/com.DefaultCompany.AvatarSLAM_plugins/files/SLAM/CameraSettings.yaml";
//    string mapfile = "/storage/emulated/0/Android/data/com.DefaultCompany.AvatarSLAM_plugins/files/SLAM/phonemap.yaml";
//    string ORBVOC = "/storage/emulated/0/Android/data/com.test.test/files/SLAM/ORBvoc.txt";
//    string setting = "/storage/emulated/0/Android/data/com.test.test/files/SLAM/CameraSettings.yaml";
//    string mapfile = "/storage/emulated/0/Android/data/com.test.test/files/SLAM/phonemap.yaml";
    string ORBVOC = path_name + "/SLAM/ORBvoc.txt";
    string setting = path_name + "/SLAM/CameraSettings.yaml";
    string mapfile = path_name + "/SLAM/phonemap.yaml";
    cv::FileStorage fSettings(setting, cv::FileStorage::READ);
    fx = fSettings["Camera.fx"];
    fy = fSettings["Camera.fy"];
    cx = fSettings["Camera.cx"];
    cy = fSettings["Camera.cy"];

    timeStamp=0;
    LOGD("initialized");
//    LOGD("path-- %s",package_name.c_str());
    slamSys=new ORB_SLAM2::System(ORBVOC,setting,ORB_SLAM2::System::MONOCULAR);
    osmap = new ORB_SLAM2::Osmap(*slamSys);
    //osmap->mapLoad(mapfile);
    return true;
}
void load_map(){
    osmap->mapLoad(file_path + "/SLAM/phonemap.yaml");
}
bool image2CVMAT(Color32 **rawImage, int width, int height){

    cv::Mat image(height, width, CV_8UC4, *rawImage);
    cv::resize(image, image, cv::Size(640, 480));
    //flip(image, image, 0);
    cv::cvtColor(image, image, cv::COLOR_RGBA2BGR);
    image.copyTo(pSrc);
    return true;
}

int slam_run(){
//        if (pSrc.empty()){
//            cv::waitKey(30);
//        }
        timeStamp += 1/30.0;
        Tcw= slamSys->TrackMonocular(pSrc,timeStamp);
        int status = slamSys->GetTrackingState();
        if (!Tcw.empty())
        {
            cv::Mat Rcw(3, 3, CV_32F);
            cv::Mat tcw(3,1,CV_32F);

            Rcw = Tcw.rowRange(0, 3).colRange(0, 3);
//            tcw = -Rcw*Tcw.rowRange(0,3).col(3);
//            vector<float> q = ORB_SLAM2::Converter::toQuaternion(Rcw);
//            translation[0] = tcw.at<float>(0,0);
//            translation[1] = tcw.at<float>(0,1);
//            translation[2] = tcw.at<float>(0,2);
//            quaternion[0] = q[0];
//            quaternion[1] = q[1];
//            quaternion[2] = q[2];
//            quaternion[3] = q[3];
            tcw = Tcw.rowRange(0, 3).col(3);

            mModelview_matrix[0] = Rcw.at<float>(0, 0);
            mModelview_matrix[1] = Rcw.at<float>(1, 0);
            mModelview_matrix[2] = Rcw.at<float>(2, 0);
            mModelview_matrix[3] = 0.0;

            mModelview_matrix[4] = Rcw.at<float>(0, 1);
            mModelview_matrix[5] = Rcw.at<float>(1, 1);
            mModelview_matrix[6] = Rcw.at<float>(2, 1);
            mModelview_matrix[7] = 0.0;

            mModelview_matrix[8] = Rcw.at<float>(0, 2);
            mModelview_matrix[9] = Rcw.at<float>(1, 2);
            mModelview_matrix[10] = Rcw.at<float>(2, 2);
            mModelview_matrix[11] = 0.0;

            mModelview_matrix[12] = tcw.at<float>(0);
            mModelview_matrix[13] = tcw.at<float>(1);
            mModelview_matrix[14] = tcw.at<float>(2);
            mModelview_matrix[15] = 1.0;
        }
    return status;
}
double* get_modelview_matrix()
{
//    unique_lock<mutex> lock(mMutex);
    return mModelview_matrix;
}
double* get_translation()
{
//    unique_lock<mutex> lock(mMutex);
    return translation;
}
double* get_quaternion()
{
//    unique_lock<mutex> lock(mMutex);
    return quaternion;
}
void shutdown(){

    slamSys->Shutdown();
    osmap->mapSave(file_path + "/SLAM/phonemap");
}
void save_map(){
    osmap->mapSave(file_path + "/SLAM/phonemap");
}

}

